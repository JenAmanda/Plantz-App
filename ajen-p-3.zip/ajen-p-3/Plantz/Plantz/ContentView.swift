//
//  ContentView.swift
//  Plantz
//
//  Created by Jen, Amanda on 11/29/24.
//
import SwiftUI
import UserNotifications
struct ContentView: View {
  
    @AppStorage("MenuIcon") private var MenuIcon: Bool = false
    @AppStorage("WhiteMode") private var WhiteMode: Bool = true
    @AppStorage("HideNotification") private var HideNotification: Bool = true
    @State private var reminderScheduled = false
    @State private var customInterval: Double = 30
    @State private var notificationAuthorized: Bool = false
   
    var body: some View {
        NavigationView {
            ZStack {
                Color(WhiteMode ? "BackgroundColor" : "Color")
                                .edgesIgnoringSafeArea(.all)
               
                VStack(spacing: 20) {
                    Image(MenuIcon ? "plantIcon" : "Icon")                    .resizable()
                        .scaledToFit()
                    
                    NavigationLink(destination: AppInfo()) {
                        Text(NSLocalizedString("AppInfo", comment: ""))
                             
                            .font(.title3)
                            .frame(width: 300, height: 50)
                            .background(Color("AccentColor"))
                            .foregroundColor(.secondary)
                            .cornerRadius(10)
                    }
                    NavigationLink(destination: PlantCare()) {
                        Text(NSLocalizedString("PlantCare", comment: ""))
                             
                            .font(.title3)
                            .frame(width: 300, height: 50)
                            .background(Color("AccentColor"))
                            .foregroundColor(.secondary)
                            .cornerRadius(10)
                    }
                    NavigationLink(destination: SettingsView()) {
                        Text(NSLocalizedString("Settings", comment: ""))
                            .font(.title3)
                            .frame(width: 300, height: 50)
                            .background(Color("AccentColor"))
                            .foregroundColor(.secondary)
                            .cornerRadius(10)
                    }
                    if HideNotification{
                        VStack(){
                            Text(NSLocalizedString("PlantCareReminder", comment: ""))
                                .font(.title3)
                                .padding(0)
                                .foregroundColor(.secondary)
                            
                            TextField(NSLocalizedString("EnterTime", comment: ""), value: $customInterval, format: .number)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .keyboardType(.numberPad)
                                .font(.title)
                                .padding(0)
                                .foregroundColor(.secondary)
                            
                            
                            Button(action: {
                                scheduleReminder(interval: customInterval)
                            }) {
                                Text(reminderScheduled ? NSLocalizedString("TapReschedule", comment: "") : NSLocalizedString("SetReminder", comment: ""))
                                    .font(.title)
                                    .padding(0)
                                    .foregroundColor(.secondary)
                                
                            }
                            
                            
                        }
                        .font(.title3)
                        .frame(width: 300, height: 150)
                        //.background(Color("AccentColor"))
                        .background(reminderScheduled ? Color("AccentColor2") : Color("AccentColor"))
                            .animation(.easeInOut(duration: 1), value: reminderScheduled)
                        .foregroundColor(.secondary)
                        .cornerRadius(10)
                    }
                }
            }
            .onAppear {
                checkNotificationAuthorization()
            }        }
    }
    
 
    func scheduleReminder(interval: Double) {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if granted {
                
                
                    let content = UNMutableNotificationContent()
                    content.title = NSLocalizedString("PlantCareRem", comment: "")
                content.body = NSLocalizedString("DoNotForget", comment: "")
                content.sound = .default
                    
                    let trigger = UNTimeIntervalNotificationTrigger(timeInterval: interval, repeats: false)
                    let request = UNNotificationRequest(identifier: "PlantCareReminder", content: content, trigger: trigger)
                  
                    UNUserNotificationCenter.current().add(request) { error in
                        if let error = error {
                            print("Error scheduling notification: \(error.localizedDescription)")
                        } else {
                            print("Notification scheduled.")
                            reminderScheduled = true
                        }
                    }
                
            } else if let error = error {
                print("Notification permission error: \(error.localizedDescription)")
            }
        }
    }
    
func checkNotificationAuthorization() {
    UNUserNotificationCenter.current().getNotificationSettings { settings in
        DispatchQueue.main.async {
            if settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional {
                notificationAuthorized = true
            } else {
                notificationAuthorized = false
            }
        }
    }
}
}

#Preview {
    ContentView()
}
