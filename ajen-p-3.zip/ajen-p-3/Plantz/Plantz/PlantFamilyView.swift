//
//  PlantFamilyView.swift
//  Plantz
//
//  Created by Jen, Amanda on 11/30/24.
//

import SwiftUI

struct PlantFamilyView: View {
    var plantDetails: PlantDetails 

    var body: some View {
        ScrollView() {
            Text(plantDetails.common_name)
                .font(.title)
                .fontWeight(.bold)
                .frame(maxWidth: .infinity)
                .background(Color("BackgroundColor"))
               
                .cornerRadius(10)

            
            if let imageUrl = plantDetails.default_image?.regular_url, let url = URL(string: imageUrl) {
                            AsyncImage(url: url) { image in
                                image
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 400, height: 300)
                                    
                            } placeholder: {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle())
                                    .scaleEffect(1.5)
                            }
                        } else {
                           
                            Image("Icon")
                                .resizable()
                                .scaledToFit()
                                .frame(height: 300)
                                .foregroundColor(.gray)
                                .cornerRadius(10)
                        }

                        VStack(alignment: .center, spacing: 8) {
                            let scientificName = plantDetails.scientific_name?.joined(separator: ", ") ?? NSLocalizedString("Unknown", comment: "")
                            let localizedString = NSLocalizedString("ScientificName", comment: "")
                            let finalString = "\(localizedString): \(scientificName)"
                            Text(finalString)
                                .font(.headline)
                                .foregroundColor(.secondary)
                                .padding(.bottom, 10)
                            Text(NSLocalizedString("OtherName", comment: "") + ": " +
                                (plantDetails.other_name?.isEmpty ?? true ? NSLocalizedString("Unknown", comment: "") : plantDetails.other_name!.joined(separator: ", ")))
                                .font(.headline)
                                .foregroundColor(.secondary)
                                .padding(.bottom, 10)
                            Text(NSLocalizedString("Type", comment: "")+":\(plantDetails.type ?? NSLocalizedString("Unknown", comment: ""))")
                                .foregroundColor(.secondary)
                                .padding(.bottom, 10)
                            Text(NSLocalizedString("Family", comment: "")+": \(plantDetails.family ?? NSLocalizedString("Unknown", comment: ""))")
                                .foregroundColor(.secondary)
                                .padding(.bottom, 10)
            
        }
                        .padding()
                        .background(Color("AccentColor2"))
                        .cornerRadius(10)
                    
    }
    }
}

#Preview {
    let mockImage = DefaultImage(
        original_url: "here is a  image",
        regular_url: "here is another image",
        liscense_name: "CC BY"
    )
    
    let mockPlantDetails = PlantDetails(
        id: 1,
        common_name: "Aloe Vera",
        scientific_name: ["Aloe barbadensis miller"],
        other_name: ["Aloe", "Burn Plant"],
        family: "Asphodelaceae",
        type: "Succulent",
        default_image: mockImage
    )
    
    return PlantFamilyView(plantDetails: mockPlantDetails)
}
