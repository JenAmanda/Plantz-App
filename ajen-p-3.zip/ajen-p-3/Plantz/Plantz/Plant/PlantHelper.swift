//
//  ExchangeHelper.swift
//  XChange
//
//  Created by Jen, Amanda on 11/25/24.
//

import Foundation
class PlantHelper: ObservableObject {
    let baseUrl = "https://perenual.com/api/species-care-guide-list?key=sk-SjPL674a1d08652f17827&q="

    func constructUrl(base: String) -> URL? {
        let encodedBase = base.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let urlString = baseUrl + encodedBase
        print("Constructed URL: \(urlString)")  // 4debugging
        return URL(string: urlString)
    }
    func fetchPlantDetails(plantId: Int) async throws -> PlantDetails {
        let url = URL(string: "https://perenual.com/api/species/details/\(plantId)?key=sk-SjPL674a1d08652f17827")!
        
        print("About to fetch data from: \(url)")
        //debug
        let request = URLRequest(url: url)
        let (data, response) = try await URLSession.shared.data(for: request)
        if let httpResponse = response as? HTTPURLResponse {
            print("HTTP Status Code: \(httpResponse.statusCode)") //debug
            if httpResponse.statusCode != 200 { throw URLError(.badServerResponse) } }
        if let responseString = String(data: data, encoding: .utf8) {
            print("Raw response data: \(responseString)") //debuugga
        }
        do {
            let decoder = JSONDecoder()
            let plantDetails = try decoder.decode(PlantDetails.self, from: data)
            FileManager.default.savePlantDetails(plantDetails)
            return plantDetails
        } catch {
            print("Decoding failed with error: \(error.localizedDescription)")
            if let decodingError = error as? DecodingError {
                switch decodingError {
                case .typeMismatch(let type, let context):
                    print("Type mismatch for \(type) at \(context.codingPath)")
                case .valueNotFound(let value, let context):
                    print("Value not found for \(value) at \(context.codingPath)")
                case .keyNotFound(let key, let context):
                    print("Key not found: \(key) at \(context.codingPath)")
                case .dataCorrupted(let context):
                    print("Data corrupted at \(context.codingPath): \(context.debugDescription)")
                default:
                    print("Other decoding error: \(error.localizedDescription)")
                }
            }
            throw error
        }}
    func fetchRates(base: String = "") async throws -> [PlantInfo] {
        guard let url = constructUrl(base: base) else {
            throw URLError(.badURL)
        }
        
        print("About to fetch data from: \(url)")  //debug
        
        let request = URLRequest(url: url)
        let (data, response) = try await URLSession.shared.data(for: request)
        
        if let httpResponse = response as? HTTPURLResponse {
            print("HTTP Status Code: \(httpResponse.statusCode)") //debug
            
            if httpResponse.statusCode != 200 {
                throw URLError(.badServerResponse)
            }
        }
        
        if let responseString = String(data: data, encoding: .utf8) {
            print("Raw response data: \(responseString)") //debuugga
        }
        
        do {
            let decoder = JSONDecoder()
            let plantResponse = try decoder.decode(PlantResponse.self, from: data)
            print("Successfully decoded: \(plantResponse)")
            
            if !plantResponse.data.isEmpty {
                FileManager.default.savePlantInfo(plantResponse.data)
                return plantResponse.data
            } else {
                throw URLError(.cannotParseResponse)
            }
        } catch let decodingError {
            print("Decoding failed with error: \(decodingError.localizedDescription)")
            throw decodingError  
        }
    }
}
