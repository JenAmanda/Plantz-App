//
//  Currency.swift
//  XChange
//
//  Created by Jen, Amanda on 11/25/24.
//

import Foundation
struct PlantInfo: Codable,  Identifiable{
    var id: Int
    
    var common_name: String
    var scientific_name: [String]
    var species_id: Int
    var section: [Section]?

    struct Section: Codable {
        var type: String
        var description: String
    }
}

struct PlantResponse: Codable {
    var data: [PlantInfo]
    var to: Int
    var per_page: Int
    var current_page: Int
    var last_page: Int
    var total: Int
}
