//
//  DetailedPlant.swift
//  Plantz
//
//  Created by Jen, Amanda on 11/30/24.
//

import Foundation

struct PlantDetails: Codable{
  
    
    
    var id: Int
    var common_name: String
    var scientific_name: [String]?
    var other_name: [String]?
    var family: String?
    var type: String?
    var default_image: DefaultImage?
}

struct DefaultImage: Codable {
    var original_url: String
    var regular_url: String?
var liscense_name: String?
}
