//
//  PlantCare.swift
//  Plantz
//
//  Created by Jen, Amanda on 11/29/24.
import SwiftUI
struct PlantCare: View {
    @State private var plantInfo: [PlantInfo] = []
    @State private var goString: String = ""
    @State private var showProgress: Bool = false
    @State private var showError: Bool = false
    @State private var errorMessage: String?
    @FocusState private var focus: Bool
    @State private var selectedPlant: PlantInfo?
    @State private var shouldNavigate = false

    var body: some View {
        NavigationStack {
            VStack {
                GoBarView(goString: $goString, focus: _focus, title: NSLocalizedString("SearchPlantName", comment: "")) {
                    
                    Task {
                        showProgress = true
                        plantInfo = []
                        do {
                            let helper = PlantHelper()
                            plantInfo = try await helper.fetchRates(base: goString)
                        } catch {
                            showError = true
                            errorMessage = "Failed to fetch plant info: \(error.localizedDescription)"
                        }
                        showProgress = false
                    }
                }

                if showProgress {
                    ProgressView()
                } else {
                    List(plantInfo, id: \.species_id) { plant in
                        Text("\(plant.common_name): \(plant.scientific_name)")
                            .font(.headline)
                            .onTapGesture {
                                selectedPlant = plant
                                shouldNavigate = true
                            }
                    }
                }
            }
            .onAppear {
                if let cachedData = FileManager.default.getPlantInfo() {
                    plantInfo = cachedData
                }
            }
            .alert(isPresented: $showError) {
                Alert(title: Text("Error"), message: Text(errorMessage ?? ""), dismissButton: .default(Text("OK")))
            }
            .navigationDestination(isPresented: $shouldNavigate) {
                if let selectedPlant = selectedPlant {
                    PlantDetailView(plant: selectedPlant)
                }
            }
        }
    }
}

#Preview {
    PlantCare()
        .environmentObject(PlantHelper())
}
