//
//  PlantDetailView.swift
//  Plantz
//
//  Created by Jen, Amanda on 12/1/24.
//

import Foundation
import SwiftUI

struct PlantDetailView: View {
    var plant: PlantInfo
    @State private var isShowingActionSheet = false
    @State private var shouldNavigate = false
    @State private var plantDetails: PlantDetails?
    @State private var showError: Bool = false
    @State private var errorMessage: String?
    @State private var isPulsing = false
    @AppStorage("ShowMoreDetails") private var ShowMoreDetails: Bool = true
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                
                Text(plant.common_name)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                Text(NSLocalizedString("PlantID", comment: "")+": \(plant.id)")
                    .font(.headline)
                let scientificName = plant.scientific_name.joined(separator: ", ")
                let localizedString = NSLocalizedString("ScientificName", comment: "")
                let finalString = "\(localizedString): \(scientificName)"
                Text(finalString)
               
                    .font(.headline)
                
                if let sections = plant.section {
                    ForEach(sections, id: \.type) { section in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(section.type.capitalized)
                                .font(.headline)
                                .foregroundColor(.secondary)
                            
                            Text(section.description)
                                .font(.body)
                                .foregroundColor(.primary)
                                .padding(.bottom, 10)
                        }
                        .padding()
                        .background(Color("AccentColor2"))
                        .cornerRadius(10)
                    }
                } else {
                    Text(NSLocalizedString("NoCareInfo", comment: ""))
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                // More Info Button custom feature, different api fetch uses id data for another spefici search
                
                if ShowMoreDetails{
                    Button(action: {
                        isShowingActionSheet = true
                    }) {
                        Text(NSLocalizedString("MoreInfo", comment: ""))
                        
                }
                    .scaleEffect(isPulsing ? 1.2 : 1.0)
                    .animation(
                        .easeInOut(duration: 0.8)
                        .repeatForever(autoreverses: true),
                        value: isPulsing   )
                    .actionSheet(isPresented: $isShowingActionSheet) {
                    ActionSheet(
                        title: Text(NSLocalizedString("PlantOp", comment: "")),
                        message: Text(NSLocalizedString("WhatWantWithPlant", comment: "")),
                        buttons: [
                            .default(Text(NSLocalizedString("ViewMoreDetails", comment: ""))) {
                                Task {
                                    await fetchPlantDetails()
                                    shouldNavigate = true
                                }
                            },
                            .cancel()
                        ]
                    )
                }
            }
                Spacer()
                    .onAppear(){
                        isPulsing = true
                    }
            }
            .padding()
        }
        .navigationDestination(isPresented: $shouldNavigate) {
            if let plantDetails = plantDetails {
                PlantFamilyView(plantDetails: plantDetails)
            }
        }
        .alert(isPresented: $showError) {
            Alert(title: Text("Error"), message: Text(errorMessage ?? ""), dismissButton: .default(Text("OK")))
        }
    }

    func fetchPlantDetails() async {
        let helper = PlantHelper()
        do {
            plantDetails = try await helper.fetchPlantDetails(plantId: plant.species_id)
            FileManager.default.savePlantDetails(plantDetails!)
        } catch {
            showError = true
            errorMessage = "Failed to fetch plant details: \(error.localizedDescription)"
        }
    }
}

#Preview {
    
    
    let mockSection = PlantInfo.Section(
        type: "Watering",
        description: "Water the plant once every two weeks."
    )

    
    let mockPlant = PlantInfo(
        id: 1,
        common_name: "Aloe Vera",
        scientific_name: ["Aloe barbadensis miller"],
        species_id: 101,
        section: [mockSection]
    )

    
    return PlantDetailView(plant: mockPlant)
}
