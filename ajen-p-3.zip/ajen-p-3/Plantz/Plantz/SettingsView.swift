//
//  SettingsView.swift
//  Plantz
//
//  Created by Jen, Amanda on 11/29/24.
//

import SwiftUI
import UserNotifications

struct SettingsView: View {
    
    @AppStorage("HideNotification") private var HideNotifcation: Bool = true
    @AppStorage("ShowMoreDetails") private var ShowMoreDetails: Bool = true
    @AppStorage("MenuIcon") private var MenuIcon: Bool = false
    @AppStorage("WhiteMode") private var WhiteMode: Bool = true
    
    @State private var notificationAuthorized: Bool = false
    
    var body: some View {
        ZStack {
            Color("AccentColor2")
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                Image("plantIcon")
                    .resizable()
                    .scaledToFit()
                
                    Button(action: {
                        ShowMoreDetails.toggle()
                    }) {
                        Text(ShowMoreDetails ? NSLocalizedString("TurnOffDetail", comment: "") : NSLocalizedString("TurnOnDetail", comment: ""))
                            .font(.title3)
                            .frame(width: 300, height: 50)
                            .background(Color.secondary.opacity(0.3))
                            .foregroundColor(.secondary)
                            .cornerRadius(10)
                    }
                
                
                Button(action: {
                    HideNotifcation.toggle()
                }) {
                    Text(HideNotifcation ? NSLocalizedString("HideReminder", comment: "") : NSLocalizedString("ShowReminder", comment: ""))
                        .font(.title3)
                        .frame(width: 300, height: 50)
                        .background(Color.secondary.opacity(0.3))
                        .foregroundColor(.secondary)
                        .cornerRadius(10)
                }
                
                Button(action: {
                    WhiteMode.toggle()
                }) {
                    Text(WhiteMode ? NSLocalizedString("TurnOnWhite", comment: "") : NSLocalizedString("TurnOffWhite", comment: ""))
                        .font(.title3)
                        .frame(width: 300, height: 50)
                        .background(Color.secondary.opacity(0.3))
                        .foregroundColor(.secondary)
                        .cornerRadius(10)
                }
                
                Button(action: {
                    MenuIcon.toggle()
                }) {
                    Text(MenuIcon ? NSLocalizedString("TurnOnDefaultIcon", comment: "") : NSLocalizedString("TurnOffDefaultIcon", comment: ""))
                        .font(.title3)
                        .frame(width: 300, height: 50)
                        .background(Color.secondary.opacity(0.3))
                        .foregroundColor(.secondary)
                        .cornerRadius(10)
                }
                
            }
        }
        
    }
}

#Preview {
    SettingsView()
}
