//
//  FileManger+Exchange.swift
//  XChange
//
//  Created by Jen, Amanda on 11/25/24.
//

import Foundation

let fileName = "PlantFile.json" //store excahnge data in fil
let pdFile = "PlantDetails.json"

extension FileManager {
    
    private func createApplicationSupportDirectory() {
        if let url = urls(for: .documentDirectory, in: .userDomainMask).first {
            var isDir: ObjCBool = true
            if !fileExists(atPath: url.path, isDirectory: &isDir) {
                do {
                    try createDirectory(atPath: url.path, withIntermediateDirectories: true, attributes: nil)
                } catch {
                    print("Error creating directory: \(error.localizedDescription)")
                }
            }
        }
    }

    func getPlantInfo() -> [PlantInfo]? {
        createApplicationSupportDirectory()
        if let url = urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent(fileName) {
            if let jsonData = contents(atPath: url.path) {
                let decoder = JSONDecoder()
                do {
                    return try decoder.decode([PlantInfo].self, from: jsonData)
                } catch {
                    print("Error decoding JSON data: \(error.localizedDescription)")
                }
            }
        }
        return nil
    }
    
    func savePlantInfo(_ plantInfo: [PlantInfo]) {
         createApplicationSupportDirectory()
         if let url = urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent(fileName) {
             do {
             
                 if fileExists(atPath: url.path) {
                     try removeItem(at: url)
                 }
                
                 
                 let encoder = JSONEncoder()
                 let encodedData = try encoder.encode(plantInfo)
                 createFile(atPath: url.path, contents: encodedData, attributes: nil)
             } catch {
                 print("Error saving data: \(error.localizedDescription)")
             }
         }
     }
    
    func getPlantDetails(for plantId: Int) -> PlantDetails? {
        createApplicationSupportDirectory()
        if let url = urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent(pdFile) {
            if let jsonData = contents(atPath: url.path) {
                let decoder = JSONDecoder()
                do {
                    return try decoder.decode(PlantDetails.self, from: jsonData)
                } catch {
                    print("Error decoding JSON data: \(error.localizedDescription)")
                }
            }
        }
        return nil
    }
   
    
    func savePlantDetails(_ plantDetails: PlantDetails) {
         createApplicationSupportDirectory()
         if let url = urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent(pdFile) {
             do {
             
                 if fileExists(atPath: url.path) {
                     try removeItem(at: url)
                 }
                
                 // Save new data
                 let encoder = JSONEncoder()
                 let encodedData = try encoder.encode(plantDetails)
                 createFile(atPath: url.path, contents: encodedData, attributes: nil)
             } catch {
                 print("Error saving data: \(error.localizedDescription)")
             }
         }
     }
}
