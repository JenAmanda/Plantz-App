//
//  AppInfo.swift
//  Plantz
//
//  Created by Jen, Amanda on 11/29/24.
//

import SwiftUI

struct AppInfo: View {
    
    let appName = Bundle.main.displayName ?? NSLocalizedString("UnknownApp", comment: "")
    let version = Bundle.main.version ?? NSLocalizedString("UnknownVersion", comment: "")
    let build = Bundle.main.build ?? NSLocalizedString("UnknownBuild", comment: "")
    let copy = Bundle.main.copyright ?? NSLocalizedString("UnknownCopy", comment: "")
    var body: some View {
        ZStack {
            Color("BackgroundColor")
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                Image("Icon")
                    .resizable()
                    .scaledToFit()
                
                
               
                Text("\(NSLocalizedString("App", comment: "")): \(appName)")
                        .font(.title)
                        .foregroundColor(.black)
                        .cornerRadius(10)
                
                
                Text("\(NSLocalizedString("Build", comment: "")): \(build)")

                    .font(.title)
                        .foregroundColor(.black)
                        .cornerRadius(10)
                
                
                
                Text("\(NSLocalizedString("Version", comment: "")): \(version)")

                        .font(.title)
                        .foregroundColor(.black)
                        .cornerRadius(10)
                Text("\(NSLocalizedString("Copy", comment: "")): \(copy)")

                    .font(.title)
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
    }
}

#Preview {
    AppInfo()
}

