//
//  PlantzApp.swift
//  Plantz
//
//  Created by Jen, Amanda on 11/29/24.
//

import SwiftUI
import UserNotifications

@main
struct PlantzApp: App {
   
    init() {
        requestNotificationPermission()
    }
   
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
   
    func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if granted {
                print("Notification permissions granted.")
                scheduleReminder()  // Schedule a reminder after permission is granted
            } else if let error = error {
                print("Error requesting notification permissions: \(error.localizedDescription)")
            }
        }
    }
   
    func scheduleReminder() {
        let content = UNMutableNotificationContent()
        content.title = "Plant Care Reminder"
        content.body = "Don't forget to check the latest tips for your plants!"
        content.sound = .default
       
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 30, repeats: false) //just for default testing
        let request = UNNotificationRequest(identifier: "PlantCareReminder", content: content, trigger: trigger)
       
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Error scheduling notification: \(error.localizedDescription)")
            } else {
                print("Notification scheduled.")
            }
        }
    }
}
